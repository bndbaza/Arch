vim.opt.termguicolors = true

function SetColor(color)
	-- color = color or "poimandres"
	color = color or "edge"
	vim.cmd.colorscheme(color)
end

SetColor()
