import os

if 1==1:
    for i in range(1,100):
        print(i)
        print()
