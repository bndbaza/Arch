from subprocess import run, Popen, PIPE
import random
import time
import os, fnmatch
import json

lis = []
j = Popen(f'hyprctl monitors -j',stdout=PIPE,encoding='utf-8',shell=True)
stdout,_ = j.communicate()
stdout = json.loads(stdout)

def app_list():
    for _, _, files in os.walk('/home/viktor/.config/hypr/'):
        for file in files:
            if fnmatch.fnmatch(file,"*.jpg"):
                new_file = file.replace('(','').replace(')','')
                os.rename(f'/home/viktor/.config/hypr/{file}',f'/home/viktor/.config/hypr/{new_file}')
                lis.append(new_file)

while True:
    if len(lis) == 0:
        app_list()
    x = random.randint(0,len(lis)-1)
    run(f'hyprpaper',shell=True)
    run(f'hyprctl hyprpaper unload all',shell=True)
    run(f'hyprctl hyprpaper preload ~/.config/hypr/{lis[x]}',shell=True)
    for std in stdout:
        run(f'hyprctl hyprpaper wallpaper "{std["name"]},~/.config/hypr/{lis[x]}"',shell=True)
    lis.remove(lis[x])
    print(len(lis))
    time.sleep(60)
